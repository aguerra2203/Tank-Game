// Fill out your copyright notice in the Description page of Project Settings.


#include "TankGame/EnemyWaypointComponent.h"
#include "TankGame/TankGameState.h"
#include "TankGame/TankGameMode.h"
#include "Kismet/GameplayStatics.h"

// Sets default values for this component's properties
UEnemyWaypointComponent::UEnemyWaypointComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...


}


// Called when the game starts
void UEnemyWaypointComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


// Called every frame
void UEnemyWaypointComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
	ATankGameState* TankGameState = GetWorld()->GetGameState<ATankGameState>();

	AActor* OwningActor = GetOwner();
	FVector CurrentLocation = OwningActor->GetActorLocation();
	FVector NewPos;

	if (!TankGameState->Win && !TankGameState->Lose) {

		if (WaypointArray.IsEmpty()) {
			return;
		}

		if (index >= WaypointArray.Num()) {
			index = 0;
			NewPos = CurrentLocation;
		}
		else {
			NewPos = MoveTowards(CurrentLocation, WaypointArray[index], MaxDistance);
		}

		OwningActor->SetActorLocation(NewPos);

		if (FVector::Distance(CurrentLocation, WaypointArray[index]) <= 10.f) {
			index++;
		}
	}
}

FVector UEnemyWaypointComponent::MoveTowards(const FVector& startPos, const FVector& endPos, float maxDistance)
{

	FVector NewPos = endPos - startPos;
	float magnitude = NewPos.Length();
	NewPos = NewPos.GetSafeNormal();

	if (magnitude <= maxDistance) {
		return endPos;
	}
	return startPos + NewPos * maxDistance;
}


