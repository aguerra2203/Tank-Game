// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "TankGameInstance.generated.h"

/**
 * 
 */
UCLASS()
class UTankGameInstance : public UGameInstance
{

	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Game Rules")
	int32 PersistentEnemies = -1;

	UPROPERTY(EditAnywhere, Category = "Game Rules")
	int32 PersistentAmmo = -1;
	
};
