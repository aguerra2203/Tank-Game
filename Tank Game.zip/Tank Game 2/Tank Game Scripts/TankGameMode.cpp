// Fill out your copyright notice in the Description page of Project Settings.


#include "TankGame/TankGameMode.h"
#include "TankGame/TankPlayerController.h"
#include "TankGame/TankPawn.h"
#include "TankGame/TankGameState.h"
#include "TankGame/TankGameInstance.h"
#include "TankGame/TankPlayerState.h"
#include "TankGame/Projectile.h"
#include "Kismet/GameplayStatics.h"

#pragma region Unreal Functions
ATankGameMode::ATankGameMode()
{
	// Set this Actor to call Tick() every frame. Tick() will never be called without it!
	PrimaryActorTick.bCanEverTick = true;

	// Initialize some of the defaults (blueprinting this will override it)
	// Notice the use of StaticClass to get the UClass class type properly
	DefaultPawnClass = ATankPawn::StaticClass();
	PlayerControllerClass = ATankPlayerController::StaticClass();
	GameStateClass = ATankGameState::StaticClass();
	PlayerStateClass = ATankPlayerState::StaticClass();
}

void ATankGameMode::BeginPlay()
{
	Super::BeginPlay();

	// Cache a reference to our GameState
	TankGameState = GetGameState<ATankGameState>();

	// Initialize game timer
	TankGameState->TimeRemaining = GameTime;

	// Set the number of enemies
	UTankGameInstance* TankGameInstance = GetWorld()->GetGameInstance<UTankGameInstance>();
	
	if (TankGameInstance->PersistentEnemies == -1) // If not yet initialized
	{
		// Initialize the number of enemies
		TankGameInstance->PersistentEnemies = InitialEnemyCount;
	}

	// Update GameState to reflect number of enemies
	TankGameState->CurrentEnemies = TankGameInstance->PersistentEnemies;
	

	// Set the ammo
	ATankPlayerController* TankPlayerController = Cast<ATankPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(),0));
	TankPlayerState = TankPlayerController->GetPlayerState<ATankPlayerState>();
	if (TankGameInstance->PersistentAmmo == -1)
	{
		// Initialize the amount of ammo
		TankGameInstance->PersistentAmmo = InitialAmmoCount;
	}

	// Update GameState to reflect current ammo
	TankPlayerState->CurrentAmmo = TankGameInstance->PersistentAmmo;

}

void ATankGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	UTankGameInstance* TankGameInstance = GetWorld()->GetGameInstance<UTankGameInstance>();
	// While there's time left
	if (TankGameState->TimeRemaining > 0.f)
	{
		// Decrement timer and check for game completion
		TankGameState->TimeRemaining -= DeltaTime;
		UE_LOG(LogTemp, Display, TEXT("Current Enemies: %i"), TankGameState->CurrentEnemies);
		

		// If time has run out
		if (TankGameState->TimeRemaining <= 0.f)
		{
			// End the game
			TankGameState->TimeRemaining = 0.f;
			TankGameInstance->PersistentEnemies = -1;
			TankGameInstance->PersistentAmmo = -1;
			TankGameState->Lose = true;
			UE_LOG(LogTemp, Display, TEXT("Ran out of time, Game Over!"));
			
		}

		//If ammo is depleated, end the game
		if (TankPlayerState->CurrentAmmo == 0) {
			TankGameState->Lose = true;
			TankGameState->TimeRemaining = 0.f;
			TankGameInstance->PersistentEnemies = -1;
			TankGameInstance->PersistentAmmo = -1;
			UE_LOG(LogTemp, Display, TEXT("Ran out of ammo, Game Over!"));
		}

		if (TankGameState->CurrentEnemies == 0) {
			TankGameState->Win = true;
			UE_LOG(LogTemp, Display, TEXT("Enemies defeated, You Win!"));
		}
	}
}
#pragma endregion
