// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "TankGame/TankGameState.h"
#include "TankGame/TankPlayerState.h"
#include "TankGameMode.generated.h"

UCLASS()
class ATankGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	ATankGameMode();

#pragma region Unreal Functions
protected:
	virtual void BeginPlay() override;

public:
	virtual void Tick(float DeltaTime) override;
#pragma endregion

public:
	UPROPERTY(EditAnywhere, Category = "Game Rules")
	float GameTime = 120.f;

	UPROPERTY(EditAnywhere, Category = "Game Rules")
	int32 InitialEnemyCount = 3;

	UPROPERTY(EditAnywhere, Category = "Game Rules")
	int32 InitialAmmoCount = 6;

	// Pointer to our GameState object of our custom type
	ATankGameState* TankGameState;
	ATankPlayerState* TankPlayerState;
};
