// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "TankGameState.generated.h"

/**
 *
 */
UCLASS()
class ATankGameState : public AGameStateBase
{
	GENERATED_BODY()

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Game Rules")
	float TimeRemaining = -1.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Game Rules")
	int32 CurrentEnemies = -1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	bool Win = false;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	bool Lose = false;
};
