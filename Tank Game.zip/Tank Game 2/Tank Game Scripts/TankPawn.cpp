// Fill out your copyright notice in the Description page of Project Settings.


#include "TankPawn.h"
#include "Components/InputComponent.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "GameFramework/SpringArmComponent.h"
#include "TankGame/ProjectileComponent.h"
#include "TankGame/Projectile.h"
#include "TankGame/TankGameMode.h"
#include "TankGame/TankPlayerState.h"
#include "Kismet/GameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "Engine/World.h"

// Sets default values
ATankPawn::ATankPawn()
{
    // Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;

    // Create the Static Mesh as the Root component
    StaticMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Static Mesh"));
    SetRootComponent(StaticMesh);

    TurretMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Turret Mesh"));
    TurretMesh->SetupAttachment(GetRootComponent());

    ProjectileComponent = CreateDefaultSubobject<UProjectileComponent>(TEXT("Projectile Component"));
    ProjectileComponent->SetupAttachment(TurretMesh);

    // Create the Spring Arm, attach it to the Root component, and rotate it with control rotation
    SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("Spring Arm"));
    SpringArm->SetupAttachment(GetRootComponent());
    SpringArm->bUsePawnControlRotation = true;

    // Create the Camera and attach it to the Spring Arm
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
    Camera->SetupAttachment(SpringArm);

}

// Called when the game starts or when spawned
void ATankPawn::BeginPlay()
{
    Super::BeginPlay();

    // Get the associated PlayerController
    if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
    {
        // Get the Enhanced Input Local Player Subsystem from the PlayerController (and the LocalPlayer)
        if (UEnhancedInputLocalPlayerSubsystem* EILPSubsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
        {
            // Use the subsystem to add the mapping context
            EILPSubsystem->AddMappingContext(PawnContext, 0);
        }
    }


}

// Called every frame
void ATankPawn::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);


}

// Called to bind functionality to input
void ATankPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    // Take our PlayerInputComponent (of type UInputComponent) and cast it to a UEnhancedInputComponent
// This lets us tap into the features of the new Enhanced Input system (vs. the old input system)
// CastChecked is like Cast, but will crash on failure

        if (UEnhancedInputComponent* EnhancedInputComponent = CastChecked<UEnhancedInputComponent>(PlayerInputComponent))
        {
            // Bind Input Actions to Callback Functions
            EnhancedInputComponent->BindAction(MoveAction, ETriggerEvent::Triggered, this, &ATankPawn::MoveCallback);
            EnhancedInputComponent->BindAction(LookAction, ETriggerEvent::Triggered, this, &ATankPawn::LookCallback);
            EnhancedInputComponent->BindAction(ShootAction, ETriggerEvent::Triggered, this, &ATankPawn::ShootCallback);
        }
}

#pragma region Input Callbacks

void ATankPawn::MoveCallback(const FInputActionValue& Value)
{
    FVector2D MoveInput = Value.Get<FVector2D>();
    UE_LOG(LogTemp, Display, TEXT("Move Input: %s"), *MoveInput.ToString());

    if (Controller != nullptr)
    {
        ATankGameState* TankGameState = Cast<ATankGameState>(UGameplayStatics::GetGameState(GetWorld()));
        if (!TankGameState->Win && !TankGameState->Lose) {
            // Get DeltaTime from the world
            float DeltaTime = GetWorld()->GetDeltaSeconds();

            // Add forward movement
            FVector MoveDirection = (GetActorForwardVector() * MoveInput.Y * MoveSpeed * DeltaTime);
            AddActorWorldOffset(MoveDirection, true);

            // Add horizontal rotation
            FQuat RotationAmount = FQuat(GetActorUpVector(), FMath::DegreesToRadians(RotationSpeed) * MoveInput.X * DeltaTime);
            AddActorWorldRotation(RotationAmount, true);

            // We changed the actor's rotation, so update the barrel rotation
            RotateTurret();
        }
    }
}

void ATankPawn::LookCallback(const FInputActionValue& Value)
{
    ATankGameState* TankGameState = Cast<ATankGameState>(UGameplayStatics::GetGameState(GetWorld()));
    if (!TankGameState->Win && !TankGameState->Lose) {

        FVector2D LookInput = Value.Get<FVector2D>();
        UE_LOG(LogTemp, Display, TEXT("Look Input: %s"), *LookInput.ToString());

        // LookUp
        AddControllerPitchInput(LookInput.Y);

        // LookRight
        AddControllerYawInput(LookInput.X);

        // We changed the control rotation, so update the barrel rotation
        RotateTurret();
    }
}

void ATankPawn::ShootCallback(const FInputActionValue& Value)
{

    ATankGameState* TankGameState = Cast<ATankGameState>(UGameplayStatics::GetGameState(GetWorld()));
    if (TankGameState && !TankGameState->Win && !TankGameState->Lose) {
        UE_LOG(LogTemp, Display, TEXT("Fire!"));

        FVector SpawnLocation = ProjectileComponent->GetComponentLocation();
        FRotator SpawnRotation = TurretMesh->GetComponentRotation();
        FActorSpawnParameters Params;

        Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        AProjectile* SpawnedProjectile = GetWorld()->SpawnActor<AProjectile>(AProjectile::StaticClass(), SpawnLocation, SpawnRotation, Params);

        UE_LOG(LogTemp, Display, TEXT("Projectile Spawned at (%s)"), *SpawnLocation.ToString());


        //if (ATankPlayerState* TankPlayerState = Cast<ATankPlayerState>(UGameplayStatics::GetPlayerState(this, 0)))
        if (ATankPlayerState* TankPlayerState = GetController()->GetPlayerState<ATankPlayerState>())
        {
            UE_LOG(LogTemp, Display, TEXT("TANK PLAYER STATE"));
            TankPlayerState->CurrentAmmo = TankPlayerState->CurrentAmmo - 1;

        }

    }
}

#pragma endregion

void ATankPawn::RotateTurret()
{
    if (Controller != nullptr)
    {
        // Get the forward direction of our control rotation
        FVector ForwardDirection = FRotationMatrix(Controller->GetControlRotation()).GetScaledAxis(EAxis::X);

        // If we want "forward" to be flat, remove the vertical component
        ForwardDirection.Z = 0;
        ForwardDirection.Normalize();

        // Set the world rotation to match the forward direction
        TurretMesh->SetWorldRotation(ForwardDirection.Rotation());
    }
}