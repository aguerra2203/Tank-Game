// Fill out your copyright notice in the Description page of Project Settings.


#include "TankGame/TankPlayerController.h"
#include "Components/InputComponent.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Blueprint/UserWidget.h"
#include "InputActionValue.h"

void ATankPlayerController::BeginPlay()
{
    // Unless you have a good reason not to, you should always call
    // the Super version of any functions Unreal gives you
    Super::BeginPlay();

    // Get the Enhanced Input Local Player Subsystem from the PlayerController (and the LocalPlayer)
    if (UEnhancedInputLocalPlayerSubsystem* EILPSubsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer()))
    {
        // Use the subsystem to add the mapping context
        EILPSubsystem->AddMappingContext(ControllerContext, 100);
    }

    if (HUDClass) {
        HUDWidget = CreateWidget(this, HUDClass);

        if (HUDWidget) {
            UE_LOG(LogTemp, Display, TEXT("HUD Widget Created"));
            HUDWidget->AddToViewport();
        }
    }

    if (EndUIClass) {
        EndUIWidget = CreateWidget(this, EndUIClass);

        if (EndUIWidget) {
            UE_LOG(LogTemp, Display, TEXT("End UI Widget Created"));
            EndUIWidget->AddToViewport();
        }
    }
}

void ATankPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();

    // Take our PlayerInputComponent (InputComponent) and cast it to a UEnhancedInputComponent
    // This lets us tap into the features of the new Enhanced Input system
    // CastChecked is like Cast, but will crash on failure
    if (UEnhancedInputComponent* EnhancedInputComponent = CastChecked<UEnhancedInputComponent>(InputComponent))
    {
        // Bind Input Actions to Callback Functions
        EnhancedInputComponent->BindAction(PauseAction, ETriggerEvent::Triggered, this, &ATankPlayerController::PauseCallback);
    }
}

void ATankPlayerController::PauseCallback(const FInputActionValue& Value)
{
    UE_LOG(LogTemp, Display, TEXT("Pause Input"));

    // Resume the game if paused, and pause otherwise
    if (IsPaused()) { SetPause(false); }
    else { Pause(); }
}
