// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "Blueprint/UserWidget.h"
#include "TankPlayerController.generated.h"

/**
 * 
 */

class UInputMappingContext;
class UInputAction;
struct FInputActionValue;


UCLASS()
class ATankPlayerController : public APlayerController
{
	GENERATED_BODY()

#pragma region Unreal Functions
protected:
	virtual void BeginPlay() override;

	virtual void SetupInputComponent() override;
#pragma endregion


private:
#pragma region Inputs

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputMappingContext> ControllerContext;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> PauseAction;

#pragma endregion

#pragma region UI

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	TSubclassOf<UUserWidget> HUDClass;

	UPROPERTY()
	TObjectPtr<UUserWidget> HUDWidget;

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	TSubclassOf<UUserWidget> EndUIClass;

	UPROPERTY()
	TObjectPtr<UUserWidget> EndUIWidget;


#pragma endregion

private:
#pragma region Input Callbacks

	// Function used as a callback from an Input Action event
	void PauseCallback(const FInputActionValue& Value);

#pragma endregion
};
